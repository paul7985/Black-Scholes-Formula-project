import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np

# Paramètres de la grille
num_cases = 20  # Nombre de cases par côté
taille_case = 1  # Taille d'une case

# Initialisation de la figure
fig, ax = plt.subplots()
ax.set_xlim(0, num_cases)
ax.set_ylim(0, num_cases)

# Création de la grille
for i in range(num_cases + 1):
    plt.axvline(i, color='black', lw=1)
    plt.axhline(i, color='black', lw=1)

# Initialisation de la particule
particule, = ax.plot([], [], 'bo', markersize=8)  # Particule (point bleu)
x, y = np.random.randint(0, num_cases), np.random.randint(0, num_cases)

# Fonction d'initialisation de l'animation
def init():
    particule.set_data([], [])
    return particule,

# Fonction d'animation pour mettre à jour la position de la particule
def update(frame):
    global x, y

    # Choix aléatoire de la nouvelle direction
    direction = np.random.choice(['haut', 'bas', 'gauche', 'droite'])

    # Mettez à jour les coordonnées de la particule
    if direction == 'haut' and y < num_cases:
        y += 1
    elif direction == 'bas' and y > 1:
        y -= 1
    elif direction == 'gauche' and x > 1:
        x -= 1
    elif direction == 'droite' and x < num_cases:
        x += 1

    particule.set_data(x, y)
    return particule,

# Création de l'objet animation
ani = FuncAnimation(fig, update, frames=range(10), init_func=init, blit=True, interval=400)

# Afficher l'animation
plt.show()
